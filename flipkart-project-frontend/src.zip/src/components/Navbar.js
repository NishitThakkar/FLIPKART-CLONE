import React from 'react'
import '../css/Navbar.css'

function Navbar() {
    return (
        <div className="nav">
            <div className="nav1">
                <img src="nav1.png" />
                <h6>Top Offers</h6>
            </div>
            <div className="nav2">
                <img src="nav2.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav3">
                <img src="nav3.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav4">
                <img src="nav4.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav5">
                <img src="nav5.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav6">
                <img src="nav6.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav7">
                <img src="nav7.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav8">
                <img src="nav8.png" />
                                <h6>Top Offers</h6>

            </div>
            <div className="nav9">
                <img src="nav9.png" />
                                <h6>Top Offers</h6>

            </div>

        </div>
    )
}



export default Navbar



import React from 'react'

function Home() {
    return (
            <>
            <div className="container">
      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="akjbfakj.jpg" class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="kjabfja.jpg" class="d-block w-100" alt="..." />
          </div>
          <div class="carousel-item">
            <img src="LSNLKDan.jpg" class="d-block w-100" alt="..." />
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
    <h4 style={{ marginTop: "25px" }}>Deals of the Day [12 : 24 : 14 Left]</h4>

    {/* //---------------------------------------------------------------------------- */}

    <div className="dod" style={{ marginTop: "25px" }}>
      <div className="dod_1">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_2">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_3">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_4">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_5">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_6">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_7">
        <img src="dod1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>
    </div>
    {/* Top Deals-------------------------------------------------------------------------- */}

    <div className="top_deals">
      <img src="top_deals.jpg" />
      <img src="top_deals.jpg" />
      <img src="top_deals.jpg" />
    </div>
    <h4 style={{ marginTop: "25px"}}>Top Offers On</h4>

    {/* Top offers -------------------------------------------------------- */}

    <div className="dod">

      <div className="dod_1">
        <img src="top.jpg" />
        <h4>Sun glasses</h4>
        <p>upto 30% of</p>Boat, jbl & more
      </div>

        <div className="dod_1">
          <img src="top3.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>

        <div className="dod_1">
          <img src="top.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>
        <div className="dod_1">
          <img src="top3.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>
        <div className="dod_1">
          <img src="top.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>
        <div className="dod_1">
          <img src="top3.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>
        <div className="dod_1">
          <img src="top.jpg" />
          <h4>Sun glasses</h4>
          <p>upto 30% of</p>Boat, jbl & more
        </div>
    </div>
    <h4 style={{ marginTop: "25px"}}>Today’s Deals</h4>

    {/* Today deals-------------------------------------------------------------------- */}


    <div className="dod" style={{ marginTop: "25px" }}>
      <div className="dod_1">
        <img src="td1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_2">
        <img src="td2.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_3">
        <img src="td3.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_4">
        <img src="td4.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_5">
        <img src="td5.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_6">
        <img src="td6.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_7">
        <img src="td7.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>
    </div>
    <h4 style={{ marginTop: "25px" }}>Latest Launches</h4>

    {/* Latest Launches--------------------------------------------------------------- */}

    <div className="dod" style={{ marginTop: "25px" }}>
      <div className="dod_1">
        <img src="mob1.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_2">
        <img src="mob2.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_3">
        <img src="mob3.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_4">
        <img src="mob4.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_5">
        <img src="mob5.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_6">
        <img src="mob6.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>

      <div className="dod_7">
        <img src="mob7.jpg" />
        <h4>Headphone</h4>
        <p>upto 70% of</p>Boat, jbl & more
      </div>
    </div>

            </>
    )
}

export default Home

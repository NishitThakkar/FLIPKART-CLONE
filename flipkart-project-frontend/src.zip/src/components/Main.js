import React from 'react'
import '../css/Main.css'
function Main() {
    return (
        <main>
            <div className="main">
                <div className="user uh">
                    <button className="b">CLICK HERE IF YOU ARE USER</button>
                </div>
                <div className="admin uh">
                <button className="b">CLICK HERE IF YOU ARE ADMIN</button>
                </div>
                <div className="owner uh">
                <button className="b">CLICK HERE IF YOU ARE OWNER</button>

                </div>
            </div>
        </main>
    )
}

export default Main

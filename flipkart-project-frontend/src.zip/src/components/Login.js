import React from 'react'
import '../css/Login.css'
function Login() {
    return (
        <div className="home">

            <div className="form_img">
                <img src="login-form-design-01.jpg" alt="" />
            </div>
            <div className="form">
                <div className="formm">
                    User Name :   <input type="text" name="username" placeholder="enter your username" /> <br /> <br />
                    Password :    <input type="password" name="password" placeholder="enter your password" /> <br /> <br />
                    <button type="submit" className="btn btn-success">Log In</button>
                    <br /><br />
                    OR
                    <br /><br />
                    <a href=""><h5>New in Ecommerce? Create an account</h5></a>
                </div>
            </div>

        </div>

    )
}

export default Login

import React from 'react'

function Temp() {
    return (
        <div>
            Hello
        </div>
    )
}

export default Temp

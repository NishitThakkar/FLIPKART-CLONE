import React from 'react'

function Cr_ac() {
    return (
        <div className="home">

            <div className="form">
                <div className="formm">

                    enter User Name :   <input type="text" name="username" placeholder="enter your username" /> <br /> <br />
                    enter mobile number :   <input type="text" name="username" placeholder="enter your username" /> <br /> <br />
                    enter Password :    <input type="password" name="password" placeholder="enter your password" /> <br /> <br />
                    conform Password :    <input type="password" name="password" placeholder="enter your password" /> <br /> <br />

                    <button type="submit" className="btn btn-success">Create an account</button>
                    <br /><br />
                    OR
                    <br /><br />
                    <a href=""><h5>Existing User? Log in</h5></a>
                </div>
            </div>

            <div className="form_img">
                <img src="login-form-design-01.jpg" alt="" />
            </div>

        </div>
    )
}

export default Cr_ac

import React from 'react';
import '../css/Header.css';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import Cr_ac from './Cr_ac';
import { FontAwesomeIcon, faCartPlus } from '@fortawesome/react-fontawesome'
import Home from './Home';
// import 'i'; 
function Header(props) {

    return (
        <Router>
            <header>

                <div className="logo">
                    <img src="fk_logo.png" />
                </div>

                <div className="sp">
                    <input type="text" placeholder="Serch For Products, Brands & More" />
                </div>

                <div class="login">
                    {/* <button className="login_btn">Login</button> */}
                    <ul className="login_li">
                        <li><Link exact to="/Login">Login</Link>
                        <Link exact to="/Temp">Temp</Link>
                        </li>
                    </ul>
                </div>

            <div className="more" style={{ color: "white" }}>
                <h5>More</h5>

            </div>

            <div className="cart" style={{ color: "white" }}>

                <h5>Cart</h5>
            </div>

            </header>

        </Router >

    )
}

export default Header

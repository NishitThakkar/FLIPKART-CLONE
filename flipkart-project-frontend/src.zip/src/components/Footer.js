import React from 'react'
import '../css/Footer.css'
function Footer() {
    return (
        <footer>
            <div className="loc">
                Compony Location:<br />
                9863 - 9867 Mill Road,
                Cambridge, MG09 99HT
            </div>

            <div className='h'>
                <h6>Copyright © 2021 Medicene . All Rights Reserved.</h6>
            </div>

            <div className="cs">
                24/7 Customer Service:<br />
                +1 800 559 6580, 
                +1 800 559 6588 
                Email Us: 
                info@companyname.com
            </div>

        </footer>
    )
}

export default Footer

import React from 'react'
import '../css/Navbarr.css'
function Navbarr() {
    return (
        <div className="navbar">
            <ul className="navbar__ul">
                <li><a href="home">Home</a></li>
                <li> <a href="about">About</a> </li>
                <li> <a href="about">Menu</a> </li>
                <li> <a href="about">Shop</a> </li>
                <li> <a href="about">Contact</a> </li>
            </ul>
        </div>
    )
}

export default Navbarr

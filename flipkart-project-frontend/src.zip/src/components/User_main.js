import React from 'react';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import Header from './Header';
import Navbar from './Navbar';
// import '../css/User_main.css';
import Footer from './Footer';
import Login from './Login';
import Home from './Home';
import Temp from './Temp';

function User_main() {
  return (
      <>
        {/* <Header /> */}
        {/* <Navbar /> */}
        <Switch>
        <Route path="/Login" exact component={Login}/>
          {/* <Route path="/" exact component={Home}/> */}
          <Route path="/Temp" exact component={Temp}/>

        </Switch>
        {/* <Footer /> */}

      </>
  )

}


export default User_main

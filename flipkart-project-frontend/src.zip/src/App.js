import './App.css';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import Footer from './components/Footer';
import Header from './components/Header';
import Navbar from './components/Navbar';
import Main from './components/Main';
import User_main from './components/User_main';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Navbarr from './components/Navbarr';
import Home from './components/Home';
import Cr_ac from './components/Cr_ac';
import Login from './components/Login';
import Temp from './components/Temp';


function App() {
  return (
    <Router>
      <div className="App">
        {/* <Home/> */}

        {/* <Cr_ac /> */}
        {/* <Header /> */}
        {/* <Navbar/> */}
        {/* <Navbarr/> */}
        {/* <Main /> */}
        <>
          <Header />
          {/* <Navbar /> */}
          <Switch>
            <Route path="/Login" exact component={Login} />
            {/* <Route path="/" exact component={Home}/> */}
            <Route path="/Temp" exact component={Temp}/>

          </Switch>
          {/* <Footer /> */}

        </>        {/* <Footer/> */}

      </div>


    </Router>
  );
}

export default App;
